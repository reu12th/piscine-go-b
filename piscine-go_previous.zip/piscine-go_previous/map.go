package piscine

func Map(f func(int) bool, a []int) []bool {
	newArr := make([]bool, len(a))
	for ind, val := range a {
		newVal := f(val)
		newArr[ind] = newVal
	}
	return newArr
}
