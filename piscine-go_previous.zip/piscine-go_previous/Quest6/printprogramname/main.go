package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	progName := os.Args[0]
	startIndex := 0
	nameRune := []rune{}
	if len(progName) <= 0 {
		z01.PrintRune('0')
	}

	for i := len(progName) - 1; i >= 0; i-- {
		if progName[i] == '/' {
			startIndex = i + 1
			break
		}
	}

	for _, r := range progName[startIndex:] {
		nameRune = append(nameRune, r)
	}
	for r := range nameRune {
		z01.PrintRune(nameRune[r])
	}
	z01.PrintRune('\n')
}
