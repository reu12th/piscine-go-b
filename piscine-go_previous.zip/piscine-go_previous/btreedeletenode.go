package piscine

func BTreeDeleteNode(root, node *TreeNode) *TreeNode {
	if node.Left == nil {
		root = BTreeTransplant(root, node, node.Right)
	} else if node.Right == nil {
		root = BTreeTransplant(root, node, node.Left)
	} else {
		next := node.Right
		for next.Left != nil {
			next = next.Left
		}

		if next.Parent != node {
			root = BTreeTransplant(root, next, next.Right)
			next.Right = node.Right
			if next.Right != nil {
				next.Right.Parent = next
			}
		}

		root = BTreeTransplant(root, node, next)
		next.Left = node.Left
	}
	return root
}
