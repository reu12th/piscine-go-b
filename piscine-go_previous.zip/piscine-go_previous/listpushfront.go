package piscine

func ListPushFront(l *List, data interface{}) {
	newNode := &NodeL{Data: data}

	if l.Head != nil {
		newNode.Next = l.Head
		l.Head = newNode
	} else {
		l.Head = newNode
	}
}
