package piscine

func JumpOver(str string) string {
	if str == "" {
		return "\n"
	}

	newStr := ""
	for i := 1; i <= len(str); i++ {
		if i%3 == 0 {
			newStr += string(str[i-1])
		}
	}
	newStr += "\n"
	return newStr
}
