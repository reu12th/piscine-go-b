package piscine

func ActiveBits(n int) int {
	baseTwo := convertToBaseTwo(n)

	count := 0
	for _, ch := range baseTwo {
		if ch == '1' {
			count++
		}
	}
	return count
}

func convertToBaseTwo(n int) string {
	nbr := []rune{}

	for n > 0 {
		nbr = append(nbr, rune('0'+n%2))
		n /= 2
	}

	return string(nbr)
}
