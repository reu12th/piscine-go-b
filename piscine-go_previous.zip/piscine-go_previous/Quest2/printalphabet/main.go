package main

import "github.com/01-edu/z01"

func printAlphabet() {
	for ch := 'a'; ch <= 'z'; ch++ {
		z01.PrintRune(ch)
	}
	z01.PrintRune(('\n'))
}

func main() {
	printAlphabet()
}
