package piscine

func BTreeIsBinary(root *TreeNode) bool {
	stack := []*TreeNode{}
	var prev *TreeNode
	current := root

	for current != nil || len(stack) > 0 {
		for current != nil {
			stack = append(stack, current)
			current = current.Left
		}
		current = stack[len(stack)-1]
		stack = stack[:len(stack)-1]

		if prev != nil && prev.Data >= current.Data {
			return false
		}
		prev = current
		current = current.Right
	}
	return true
}
