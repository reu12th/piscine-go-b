package piscine

func Concat(str1 string, str2 string) string {
	str := str1 + str2
	return str
}
