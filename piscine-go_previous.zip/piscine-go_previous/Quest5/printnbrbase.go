package piscine

import "github.com/01-edu/z01"

func PrintNbrBase(nbr int, base string) {
	if !baseValid(base) {
		z01.PrintRune('N')
		z01.PrintRune('V')
		return
	}

	if nbr < 0 {
		z01.PrintRune('-')
		PrintNbrInBase(uint64(-(int64(nbr))), base)
	} else {
		PrintNbrInBase(uint64(nbr), base)
	}
}

func baseValid(base string) bool {
	baseLen := len(base)

	if baseLen < 2 {
		return false
	}

	exists := make(map[rune]bool)
	for _, a := range base {
		if a == '-' || a == '+' {
			return false
		}

		if exists[a] {
			return false
		}
		exists[a] = true
	}
	return true
}

func PrintNbrInBase(nbr uint64, base string) {
	baseLen := len(base)

	if nbr >= uint64(baseLen) {
		PrintNbrInBase(nbr/uint64(baseLen), base)
	}
	digit := base[nbr%uint64(baseLen)]
	z01.PrintRune(rune(digit))
}
