package piscine

func FirstRune(s string) rune {
	for _, a := range s {
		return a
	}
	return 0
}
