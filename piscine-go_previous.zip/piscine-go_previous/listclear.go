package piscine

func ListClear(l *List) {
	l.Head = nil
	l.Tail = nil
}
