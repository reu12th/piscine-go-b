package piscine

func CountIf(f func(string) bool, tab []string) int {
	count := 0
	newArr := make([]bool, len(tab))

	for ind, val := range tab {
		newArr[ind] = f(val)
	}

	for _, val := range newArr {
		if val {
			count++
		}
	}
	return count
}
