package piscine

func Any(f func(string) bool, a []string) bool {
	newArr := make([]bool, len(a))

	for ind, val := range a {
		newArr[ind] = f(val)
	}

	for _, val := range newArr {
		if val {
			return true
		}
	}
	return false
}
