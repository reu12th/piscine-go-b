package piscine

func ListReverse(l *List) {
	var prev *NodeL
	current := l.Head
	l.Tail = l.Head

	for current != nil {
		tmp := current.Next
		current.Next = prev
		prev = current
		current = tmp
	}

	l.Head = prev
}
