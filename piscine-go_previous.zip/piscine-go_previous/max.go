package piscine

func Max(a []int) int {
	if len(a) == 0 {
		return 0
	}
	max := 0

	for _, nbr := range a {
		if nbr > max {
			max = nbr
		}
	}
	return max
}
