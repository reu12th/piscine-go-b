package piscine

func AtoiBase(s string, base string) int {
	if !isBaseValid(base) {
		return 0
	}
	baseLen := len(base)

	result := 0
	for _, ch := range s {
		val := 0
		for i, r := range base {
			if r == ch {
				val = i
			}
		}
		result = result*baseLen + val
	}

	return result
}

func isBaseValid(base string) bool {
	baseLen := len(base)

	if baseLen < 2 {
		return false
	}

	exists := make(map[rune]bool)
	for _, a := range base {
		if a == '-' || a == '+' {
			return false
		}

		if exists[a] {
			return false
		}

		exists[a] = true
	}
	return true
}
