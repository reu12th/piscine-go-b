package piscine

func Compact(ptr *[]string) int {
	count := 0

	for _, ch := range *ptr {
		if ch != "" {
			count++
		}
	}

	newStr := make([]string, count)
	j := 0
	for _, ch := range *ptr {
		if ch != "" {
			newStr[j] = ch
			j++
		}
	}
	*ptr = newStr
	return count
}
