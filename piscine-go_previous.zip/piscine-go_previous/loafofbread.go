package piscine

func LoafOfBread(str string) string {
	if str == "" {
		return "\n"
	}
	if len(str) < 5 {
		return "Invalid Output\n"
	}

	result := ""
	j := 0

	for i, ch := range str {
		if ch == ' ' && j < 5 {
			continue
		}
		if j == 5 {
			if i != len(str)-1 && str[i+1] == ' ' {
				continue
			}
			if i == len(str)-1 {
				break
			}
			result += " "
			j = 0
			continue
		}
		result += string(ch)
		j++
	}
	result += "\n"
	return result
}
