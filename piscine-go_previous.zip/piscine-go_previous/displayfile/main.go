package main

import (
	"fmt"
	"io"
	"os"
)

func main() {
	args := os.Args
	if len(args) <= 1 {
		fmt.Println("File name missing")
		return
	}
	if len(args) > 2 {
		fmt.Println("Too many arguments")
		return
	}
	fileName := args[1]
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Println(err)
		return
	}

	info, err := file.Stat()
	if err != nil {
		fmt.Println(err)
		return
	}

	size := info.Size()

	buffer := make([]byte, size)

	for {
		n, err := file.Read(buffer)
		if err != nil {
			if err == io.EOF {
				break
			}
		}
		os.Stdout.Write(buffer[:n])
	}
	file.Close()
}
