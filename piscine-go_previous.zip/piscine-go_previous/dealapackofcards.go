package piscine

import "fmt"

func DealAPackOfCards(deck []int) {
	count := 0

	for range deck {
		count++
	}
	nbrOfPlayerCards := count / 4

	for i := 0; i < 4; i++ {
		start := i * nbrOfPlayerCards
		end := start + nbrOfPlayerCards

		fmt.Printf("Player %d: ", i+1)

		for j := start; j < end; j++ {
			fmt.Printf("%d", deck[j])
			if j != end-1 {
				fmt.Printf(", ")
			}
		}
		fmt.Printf("\n")
	}
}
