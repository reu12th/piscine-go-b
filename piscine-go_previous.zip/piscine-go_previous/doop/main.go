package main

import (
	"os"
)

const (
	MaxInt = int(^uint(0) >> 1)
	MinInt = -MaxInt - 1
)

func main() {
	args := os.Args[1:]

	if len(args) != 3 {
		return
	}

	val1 := args[0]
	operand := args[1]
	val2 := args[2]

	for i, val := range val1 {
		if i == 0 && val == '-' {
			continue
		}
		if val < '0' || val > '9' {
			return
		}
	}

	for i, val := range val2 {
		if i == 0 && val == '-' {
			continue
		}
		if val < '0' || val > '9' {
			return
		}
	}

	if !(operand == "+" || operand == "-" || operand == "*" || operand == "/" || operand == "%") {
		return
	}

	var result int
	first, firstOverflows := atoi(val1)
	sec, secOverflows := atoi(val2)

	if firstOverflows || secOverflows {
		return
	}

	if sec == 0 {
		if operand == "%" {
			os.Stdout.WriteString("No modulo by 0\n")
			return
		}
		if operand == "/" {
			os.Stdout.WriteString("No division by 0\n")
			return
		}
	}

	switch operand {
	case "-":
		result = first - sec
	case "+":
		result = first + sec
		if (sec > 0 && result < first) ||
			(sec < 0 && result < first) {
			return
		}
	case "*":
		result = first * sec
		if first != 0 && (result/first != sec) {
			return
		}
	case "/":
		result = first / sec
	case "%":
		result = first % sec
	}
	printInt(result)
}

func atoi(s string) (int, bool) {
	if len(s) == 0 {
		return 0, false
	}

	isNeg := false
	var num int64 = 0
	start := 0

	if s[start] == '-' {
		isNeg = true
		start++
		if len(s) == 1 {
			return 0, true
		}
	}

	for i := start; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return 0, false
		}
		digit := int64(s[i] - '0')

		if !isNeg {
			if num > (int64(MaxInt)-digit)/10 {
				return 0, true
			}
		} else {
			if num > (-(int64(MinInt) + digit))/10 {
				return 0, true
			}
		}

		num = num*10 + digit
	}

	if isNeg {
		num = -num
	}
	if num < int64(MinInt) || num > int64(MaxInt) {
		return 0, true
	}

	return int(num), false
}

func printInt(nbr int) {
	if nbr == 0 {
		os.Stdout.Write([]byte("0\n"))
		return
	}

	i := 0
	if nbr < 0 {
		os.Stdout.Write([]byte("-"))
		nbr = -nbr
	}

	var num [20]byte

	for nbr > 0 {
		num[i] = byte(nbr%10) + '0'
		nbr /= 10
		i++
	}

	for j := i - 1; j >= 0; j-- {
		os.Stdout.Write([]byte{num[j]})
	}
	os.Stdout.Write([]byte("\n"))
}
