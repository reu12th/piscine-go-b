package piscine

func IsSorted(f func(a, b int) int, a []int) bool {
	sortDirection := 0

	for i := 0; i < len(a)-1; i++ {
		compare := f(a[i], a[i+1])
		if compare == 0 {
			continue
		}
		if sortDirection == 0 {
			sortDirection = compare
		} else {
			if sortDirection*compare < 0 {
				return false
			}
		}
	}
	return true
}
