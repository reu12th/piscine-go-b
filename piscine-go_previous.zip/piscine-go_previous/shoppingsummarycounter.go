package piscine

func ShoppingSummaryCounter(str string) map[string]int {
	uniqList := make(map[string]int)
	word := ""

	for _, ch := range str {
		if ch == 32 {
			uniqList[word]++
			word = ""
		} else if ch != 32 {
			word += string(ch)
		}
	}
	uniqList[word]++
	return uniqList
}
