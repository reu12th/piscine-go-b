package piscine

func Join(strs []string, sep string) string {
	newStr := ""

	for idx, s := range strs {
		if idx > 0 {
			newStr += sep
		}
		newStr += s
	}

	return newStr
}
