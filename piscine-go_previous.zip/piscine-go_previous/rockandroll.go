package piscine

func RockAndRoll(n int) string {
	str := ""

	if n < 0 {
		str = "error: number is negative\n"
	} else if n%2 == 0 && n%3 != 0 {
		str = "rock\n"
	} else if n%3 == 0 && n%2 != 0 {
		str = "roll\n"
	} else if n%2 == 0 && n%3 == 0 {
		str = "rock and roll\n"
	} else {
		str = "error: non divisible\n"
	}
	return str
}
