package piscine

func Rot14(s string) string {
	newStr := ""

	for _, ch := range s {
		var val rune
		if ch >= 'a' && ch <= 'z' {
			val = (ch-'a'+14)%26 + 'a'
		} else if ch >= 'A' && ch <= 'Z' {
			val = (ch-'A'+14)%26 + 'A'
		} else {
			val = ch
		}
		newStr += string(val)
	}
	return newStr
}
