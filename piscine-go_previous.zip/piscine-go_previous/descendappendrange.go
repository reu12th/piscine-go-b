package piscine

func DescendAppendRange(max, min int) []int {
	nbrs := []int{}

	if min > max {
		return []int{}
	}

	for i := max; i > min; i-- {
		nbrs = append(nbrs, i)
	}
	return nbrs
}
