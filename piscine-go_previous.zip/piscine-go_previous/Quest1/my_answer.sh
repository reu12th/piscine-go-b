#! /bin/bash
# POSSIBLE_WITNESSES=$(grep 'Annabel' people | awk '$3 == "F"')


# Extract addresses into variables
# ADDRESS1=$(echo "$POSSIBLE_WITNESSES" | awk 'NR==1 {for(i=4;i<=NF;i++) printf $i " "; print ""}' | sed 's/ *$//')
# ADDRESS2=$(echo "$POSSIBLE_WITNESSES" | awk 'NR==2 {for(i=4;i<=NF;i++) printf $i " "; print ""}' | sed 's/ *$//')

#From the address, get the interview number. Using the interview number, Determine the witness is Annabel Church

# Check for vehicle with plate number starting with L337
# With a blue color, namufactured by Honda, with the owner taller than 6'
# This returns 4 names
# grep -A 5 'L337' ../vehicles | grep -C 4 'Blue' | grep -B 4 "6'" | grep -A 4 'Honda'^C

# cat AAA United_MileagePlus Museum_of_Bash_History Terminal_City_Library Delta_SkyMiles | grep  "Erika Owens"
# returns 0
# cat AAA United_MileagePlus Museum_of_Bash_History Terminal_City_Library Delta_SkyMiles | grep  "Dartey Henv"
# returns 4
# cat AAA United_MileagePlus Museum_of_Bash_History Terminal_City_Library Delta_SkyMiles | grep  "Hellen Maher"
# returns 4
# cat AAA United_MileagePlus Museum_of_Bash_History Terminal_City_Library Delta_SkyMiles | grep  "Joe Germuska"
# returns 0

#Hellen seems to be female and so the suspect is most likely Dartey Henv
echo 'Dartey Henv'