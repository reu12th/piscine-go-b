#! /bin/bash


curl https://acad.learn2earn.ng/assets/superhero/all.json | jq --argjson var "$HERO_ID" '.[] | select( .id==$var ) | .connections.relatives' | sed 's/"//g'
