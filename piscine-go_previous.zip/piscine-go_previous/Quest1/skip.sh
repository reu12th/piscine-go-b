#! /bin/bash

ls -l | sed '1~2d' 