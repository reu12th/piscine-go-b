#! /bin/bash

echo "Annabel Church"
echo "699607"
echo "Blue Honda"
echo -e "Joe Germuska\nHellen Maher\nErika Owens"