#! /bin/bash


find . -type f -iname '*sh' -exec basename {} .sh \; | sort -r