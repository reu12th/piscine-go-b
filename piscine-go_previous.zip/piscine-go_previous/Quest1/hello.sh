#! /bin/bash
echo 'Hello aadeboga!'