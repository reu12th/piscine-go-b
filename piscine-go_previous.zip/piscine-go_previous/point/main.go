package main

import (
	"github.com/01-edu/z01"
)

type point struct {
	x int
	y int
}

func setPoint(ptr *point) {
	ptr.x = 42
	ptr.y = 21
}

func main() {
	points := &point{}

	setPoint(points)

	str := "x = "

	x := points.x

	var digits [10]rune
	count := 0

	if x < 0 {
		digits[count] += '-'
		count++
	} else if x == 0 {
		digits[count] += '0'
		count++
	} else {
		for x > 0 {
			digits[count] = ('0' + (rune)(x%10))
			count++
			x /= 10
		}
	}

	for i := count - 1; i >= 0; i-- {
		str += (string)(digits[i])
	}

	str += ", y = "

	count = 0
	y := points.y

	if y < 0 {
		digits[count] += '-'
		count++
	} else if y == 0 {
		digits[count] += '0'
		count++
	} else {
		for y > 0 {
			digits[count] = ('0' + (rune)(y%10))
			count++
			y /= 10
		}
	}

	for i := count - 1; i >= 0; i-- {
		str += (string)(digits[i])
	}

	for _, ch := range str {
		z01.PrintRune(ch)
	}
	z01.PrintRune('\n')
}
