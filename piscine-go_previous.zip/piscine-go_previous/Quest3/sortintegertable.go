package piscine

func SortIntegerTable(table []int) {
	tableLen := len(table)

	for i := 0; i < tableLen-1; i++ {
		for j := 0; j < tableLen-i-1; j++ {
			if table[j] > table[j+1] {
				tmp := table[j]
				table[j] = table[j+1]
				table[j+1] = tmp
			}
		}
	}
}
