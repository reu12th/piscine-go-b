package piscine

func UltimateDivMod(a *int, b *int) {
	if b == nil || *b == 0 {
		return
	}
	quotient := *a / *b
	remainder := *a % *b
	*a = quotient
	*b = remainder
}
