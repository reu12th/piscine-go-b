package piscine

func StrRev(s string) string {
	revStr := ""

	for i := len(s) - 1; i >= 0; i-- {
		revStr += string(s[i])
	}
	return revStr
}
