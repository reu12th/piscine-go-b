package main

import "os"

func main() {
	args := os.Args[1:]

	for _, ch := range args {
		if ch == "01" || ch == "galaxy" || ch == "galaxy 01" {
			os.Stdout.WriteString("Alert!!!\n")
			return
		}
	}
}
