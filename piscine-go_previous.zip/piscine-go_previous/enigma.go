package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	tempA := ***a
	tempB := *b
	tempC := *******c
	tempD := ****d

	***a = tempB
	*b = tempD
	*******c = tempA
	****d = tempC
}
