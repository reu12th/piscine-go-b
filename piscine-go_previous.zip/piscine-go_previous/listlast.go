package piscine

func ListLast(l *List) interface{} {
	current := l.Head

	for current != nil && current.Next != nil {
		current = current.Next
	}

	if current != nil {
		return current.Data
	}
	return nil
}
